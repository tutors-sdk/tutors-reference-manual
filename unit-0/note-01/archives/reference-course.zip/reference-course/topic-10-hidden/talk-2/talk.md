---
icon:
  type: bi:filetype-pptx
  color: green
---
Hidden Lecure

This lecture should not appear in the wall