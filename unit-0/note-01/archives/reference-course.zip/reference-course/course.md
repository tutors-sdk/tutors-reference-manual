# Reference Course

A short description of the course. This description will be available when the information icon in the top left selected.

This can be any markdown document:

- with the usual
- markdown facilities

## Can include Headings

And even tables ...

| Head 1 | Head 2 |
| ------ | ------ |
| cell 1 | cell 2 |
| cell 3 | cell 4 |
