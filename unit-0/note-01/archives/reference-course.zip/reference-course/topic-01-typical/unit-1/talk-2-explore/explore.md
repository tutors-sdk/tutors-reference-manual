Lecture 2

Provide a short summary, perhaps supported by a representative image.