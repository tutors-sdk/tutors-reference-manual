Lecture 5

A short summary of the talk, no more than two sentences.