Lecture 7

This is just a video link, no slides