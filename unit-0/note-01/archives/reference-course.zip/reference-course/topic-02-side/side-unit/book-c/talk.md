Problem Sheet 1

A Problem Sheet (lab), presented as a PDF