Lecture 4

Provide a short summary, perhaps supported by a representative image.