Lecture 8

This summary *can* have **markdown** styles 