---
icon:
  type: vscode-icons:file-type-pdf2
---
Lecture 10

A short summary of the talk, no more than two sentences.